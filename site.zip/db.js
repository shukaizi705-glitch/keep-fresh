import { emptyState, validateState } from './core.js';

let opening;
let revision = 0;
function database() {
  if (!opening) opening = new Promise((resolve,reject)=>{
    const request = indexedDB.open('keep-fresh',1);
    request.onupgradeneeded = () => request.result.createObjectStore('state');
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => { opening = null; reject(request.error); };
    request.onblocked = () => { opening = null; reject(new Error('请关闭其他打开此网页的标签，再重试。')); };
  });
  return opening;
}
export async function loadState() {
  const db = await database();
  return new Promise((resolve,reject)=>{
    const request = db.transaction('state').objectStore('state').get('current');
    request.onsuccess = () => {
      try {
        const stored = request.result;
        revision = stored?.revision || 0;
        resolve(stored ? validateState(stored.data || stored) : emptyState());
      } catch (error) { reject(error); }
    };
    request.onerror = () => reject(request.error);
  });
}
export async function saveState(state) {
  validateState(state);
  const db = await database();
  return new Promise((resolve,reject)=>{
    const tx = db.transaction('state','readwrite');
    const store = tx.objectStore('state');
    const read = store.get('current');
    let conflict, nextRevision;
    read.onsuccess = () => {
      const storedRevision = read.result?.revision || 0;
      if (storedRevision !== revision) {
        conflict = new Error('另一个页面已更新记录，本次未覆盖。请刷新网页后重新编辑。');
        tx.abort();
        return;
      }
      nextRevision = storedRevision + 1;
      store.put({revision:nextRevision,data:state},'current');
    };
    tx.oncomplete = () => { revision = nextRevision; resolve(); };
    tx.onerror = () => reject(conflict || tx.error);
    tx.onabort = () => reject(conflict || tx.error || new Error('保存未完成，请重试。'));
  });
}
