const APP_CACHE='keep-fresh-app-v2';
const CORE=['./','./index.html','./style.css','./app.js','./core.js','./db.js','./food-catalog.js','./recipes.js','./manifest.webmanifest','./icon.svg','./icon-192.png','./icon-512.png'];
self.addEventListener('install',event=>{
  event.waitUntil(caches.open(APP_CACHE).then(cache=>cache.addAll(CORE)).then(()=>self.skipWaiting()));
});
self.addEventListener('activate',event=>{
  event.waitUntil((async()=>{
    for(const key of await caches.keys())if(key.startsWith('keep-fresh-app-')&&key!==APP_CACHE)await caches.delete(key);
    await self.clients.claim();
  })());
});
self.addEventListener('fetch',event=>{
  const url=new URL(event.request.url);
  if(event.request.method!=='GET'||url.origin!==self.location.origin)return;
  event.respondWith((async()=>{
    const cache=await caches.open(url.pathname.includes('/vendor/')?'keep-fresh-ocr-v1':APP_CACHE);
    const cached=await cache.match(event.request);
    if(cached&&url.pathname.includes('/vendor/'))return cached;
    try {
      const response=await fetch(event.request);
      if(response.ok)await cache.put(event.request,response.clone());
      return response;
    } catch(error) {
      if(cached)return cached;
      if(event.request.mode==='navigate') {
        const fallback=await caches.match(new URL('./index.html',self.registration.scope));
        if(fallback)return fallback;
      }
      throw error;
    }
  })());
});
