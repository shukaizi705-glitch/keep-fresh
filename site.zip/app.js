import {FOODS,SOURCES} from './food-catalog.js';
import {BASE_RECIPES} from './recipes.js';
import {STORAGE,CONDITIONS,DATE_TYPES,todayLocal,itemDate,itemStatus,matchFood,suggestDate,rankRecipes,parseReceipt,emptyState,createBackup,readBackup,validateState} from './core.js';
import {loadState,saveState} from './db.js';

const $ = (selector, root=document) => root.querySelector(selector);
const $$ = (selector, root=document) => [...root.querySelectorAll(selector)];
const esc = value => String(value ?? '').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const icon = name => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${({home:'<path d="m3 10 9-7 9 7v10H3Z"/><path d="M9 20v-7h6v7"/>',fridge:'<rect x="5" y="2" width="14" height="20" rx="3"/><path d="M5 9h14M9 5v1M9 13v3"/>',plus:'<path d="M12 5v14M5 12h14"/>',book:'<path d="M12 5v16M12 5C9 2 4 3 2 4v15c4-2 7-1 10 2 3-3 6-4 10-2V4c-2-1-7-2-10 1Z"/>',settings:'<path d="M4 6h16M4 12h16M4 18h16"/><circle cx="8" cy="6" r="2" fill="currentColor"/><circle cx="16" cy="12" r="2" fill="currentColor"/><circle cx="10" cy="18" r="2" fill="currentColor"/>',search:'<circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 5 5"/>',camera:'<rect x="2" y="6" width="20" height="15" rx="3"/><path d="m7 6 2-3h6l2 3"/><circle cx="12" cy="13" r="4"/>',arrow:'<path d="M5 12h14m-5-5 5 5-5 5"/>',leaf:'<path d="M20 3C8 1 2 8 5 15s15 8 15-12Z"/><path d="M3 21 15 9"/>'})[name] || ''}</svg>`;
const button = (label,action,style='',attrs='') => `<button class="button ${style}" type="button" data-action="${action}" ${attrs}>${label}</button>`;
const sourceLink = id => {const source=SOURCES.find(x=>x.id===id);return source?`<a class="source" href="${esc(source.url)}" target="_blank" rel="noopener noreferrer">${esc(source.title)} ↗</a>`:'';};
const modal = $('#modal');
let state = emptyState(), page = 'today', filter = 'active', search = '', recipeFilter = 'all', busy = false;
let receipt = null, restore = null, photoDraft = '', photoProcessing = false, toastTimer;
let offlineReady = false;
const allRecipes = () => [...state.recipes,...BASE_RECIPES];
const activeItems = () => state.items.filter(item=>item.status==='active');
const ranked = () => rankRecipes(allRecipes(),state.items,FOODS,todayLocal(),state.settings.urgentDays);

function toast(message) {
  $('#toast').textContent = message;
  $('#toast').classList.add('visible');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(()=>$('#toast').classList.remove('visible'),4500);
}
function dialog(title,html,subtitle='') {
  modal.innerHTML=`<div class="dialog-head"><div><p class="eyebrow">KEEP IT FRESH</p><h2 id="dialog-title">${esc(title)}</h2>${subtitle?`<p class="hint">${esc(subtitle)}</p>`:''}</div><button class="close" type="button" data-action="close" aria-label="关闭对话框">×</button></div>${html}`;
  if (!modal.open) modal.showModal();
}
function closeDialog() { if (busy) return; modal.close(); }
async function commit(next,message='已保存') {
  validateState(next);
  await saveState(next);
  state=next;
  render();
  toast(message);
}
function navigate(next) { location.hash=next; }
function pageHead(title,subtitle,action='') {
  return `<div class="page-head"><div><p class="eyebrow">A LITTLE FRESHER, EVERY DAY</p><h1>${title}</h1><p>${subtitle}</p></div>${action}</div>`;
}
function render() {
  page = ['today','inventory','add','recipes','settings'].includes(location.hash.slice(1)) ? location.hash.slice(1) : 'today';
  const nav=[['today','home','今天'],['inventory','fridge','我的食材'],['add','plus','添加食材'],['recipes','book','我的菜谱'],['settings','settings','设置']];
  $('#navigation').innerHTML=nav.map(([id,symbol,name])=>`<a class="nav-link ${page===id?'active':''}" href="#${id}" data-page="${id}" ${page===id?'aria-current="page"':''}>${icon(symbol)}<span>${name}</span></a>`).join('');
  $('#main').innerHTML=({today:renderToday,inventory:renderInventory,add:renderAdd,recipes:renderRecipes,settings:renderSettings})[page]();
  document.title=`${nav.find(x=>x[0]===page)[2]} · 别放坏了`;
}
function foodVisual(item) {
  return `<span class="food-emoji">${item.photo?`<img src="${esc(item.photo)}" alt="${esc(item.name)}的照片">`:esc(matchFood(item.name,FOODS)?.emoji || '🥗')}</span>`;
}
function foodRow(item) {
  const status=itemStatus(item,todayLocal(),state.settings.urgentDays);
  return `<div class="food-row">${foodVisual(item)}<div class="food-info"><h3>${esc(item.name)}</h3><p>${esc(item.quantity || '份量未填')} · ${STORAGE[item.storage]} · ${esc(itemDate(item) || '日期待确认')}</p></div><div class="food-meta"><span class="badge ${status.kind}">${esc(status.label)}</span><button class="row-edit" type="button" data-action="edit-item" data-id="${esc(item.id)}" aria-label="编辑${esc(item.name)}">编辑 ↗</button></div></div>`;
}
function emptyCard(symbol,title,description,action='') { return `<div class="empty"><span class="empty-icon" aria-hidden="true">${symbol}</span><h3>${title}</h3><p>${description}</p>${action}</div>`; }
function recipeCard(match) {
  const {recipe,available,missing,urgent}=match;
  return `<article class="recipe-card"><div class="recipe-top"><div class="recipe-art" aria-hidden="true">${esc(recipe.emoji || '🍽️')}</div><div class="recipe-summary"><span class="hint">${esc(recipe.tag || '我的私房菜')} · ${esc(recipe.minutes || '—')} 分钟</span><h3>${esc(recipe.name)}</h3><p>${available.length?`可用：${available.map(x=>esc(x.name)).join('、')}`:'添加食材后查看库存匹配'}<br>${missing.length?`还缺：${missing.map(x=>esc(x.name)).join('、')}`:'所需种类齐全 · 请确认份量'}</p></div></div><div class="recipe-footer"><span class="${urgent.length?'urgent-text':''}">${urgent.length?`先用掉 ${urgent.map(x=>esc(x.name)).join('、')}`:'按现有食材匹配，份量需确认'}</span><button type="button" class="button ghost small" data-action="recipe" data-id="${esc(recipe.id)}" aria-label="查看${esc(recipe.name)}的做法">看做法 <span class="arrow">↗</span></button></div></article>`;
}
function renderToday() {
  const items=activeItems(),today=todayLocal(),days=state.settings.urgentDays;
  const groups={today:[],soon:[],review:[],expired:[],fresh:[]};
  for (const item of items) {const kind=itemStatus(item,today,days).kind;(groups[kind==='unknown'?'review':kind] || groups.review).push(item);}
  const urgent=[...groups.expired,...groups.today,...groups.soon,...groups.review].sort((a,b)=>{
    const priority=x=>({expired:0,today:1,soon:2,review:3,unknown:3}[itemStatus(x,today,days).kind]??4);
    return priority(a)-priority(b) || (itemDate(a)||'9999').localeCompare(itemDate(b)||'9999');
  });
  const date=new Date().toLocaleDateString('zh-CN',{month:'long',day:'numeric',weekday:'long'});
  return `${pageHead('今天，好好吃饭。',`${esc(date)} · 看看冰箱，给新鲜一个好去处。`,button(`${icon('plus')} 记一份食材`,'new-item'))}
    <section class="hero" aria-label="食材管理"><div class="hero-copy"><p class="eyebrow">YOUR LITTLE KITCHEN COMPANION</p><h2>把新鲜记下来，<br>把日子吃出滋味。</h2><p>买回来的每一份食材，都值得被记得。<br>从一张小票开始，轻松安排下一餐。</p>${button(`${icon('camera')} 拍小票，记食材`,'go-add','secondary')}</div><div class="hero-art" aria-hidden="true"><div class="art-leaf"></div><div class="plate"><span>🥦</span><span>🍅</span><span>🥕</span></div><span class="art-note">FRESH FOOD, GOOD MOOD.</span></div></section>
    <div class="stats" aria-label="食材概览">${[[items.length,'在库食材','♧','', 'active'],[groups.today.length,'今天到期','◷','amber','today'],[groups.soon.length,`${days} 天内到期`,'↗','amber','soon'],[groups.review.length+groups.expired.length,'需要确认','⌕',groups.expired.length?'red':'','review']].map(([value,label,symbol,color,selected])=>`<button class="stat ${color}" type="button" data-action="inventory-filter" data-filter="${selected}"><span><span class="value">${value}<small style="font-size:11px;letter-spacing:0;margin-left:5px;font-weight:400">份</small></span><span class="label">${label}</span></span><span class="stat-icon" aria-hidden="true">${symbol}</span></button>`).join('')}</div>
    <div class="columns"><section><div class="section-head"><div><h2>这些食材，先照顾<span class="count">${urgent.length}</span></h2><p>按期限排序，给它们安排下一餐。</p></div><a class="button ghost small" href="#inventory">查看全部 ↗</a></div><div class="panel">${urgent.length?urgent.slice(0,6).map(foodRow).join(''):items.length?emptyCard('🌿','新鲜都在掌握中','当前没有需要优先处理的食材。', '<a class="button soft small" href="#inventory">看看我的食材</a>'):emptyCard('🧺','还没有食材，先记一份吧','拍小票或手动添加，让你的冰箱清单从这里开始。',button('添加第一份食材','new-item','soft small'))}</div><p class="note">${icon('leaf')} 包装日期优先，系统建议仅作安排参考。保存方式或开封状态变化后，记得重新确认日期。</p></section>
    <section><div class="section-head"><div><h2>今天可以做什么</h2><p>优先用临期食材，少一点“吃什么”的纠结。</p></div><a class="button ghost small" href="#recipes">全部菜谱 ↗</a></div>${items.length?ranked().slice(0,3).map(recipeCard).join(''):`<div class="panel">${emptyCard('🍳','下一餐，从冰箱里找灵感','录入食材后，这里会推荐三道菜，并标出还缺哪些配料。','<a class="button soft small" href="#recipes">先逛逛 30 道家常菜</a>')}</div>`}<p class="hint" style="margin-top:13px">你自己的拿手菜，也可以加入推荐。 <button class="button ghost small" type="button" data-action="new-recipe">记一道菜 ↗</button></p></section></div>`;
}
function renderInventory() {
  const today=todayLocal(),days=state.settings.urgentDays;
  const rows=state.items.filter(item=>{
    const status=itemStatus(item,today,days);
    const selected=filter==='all' || filter==='active'&&item.status==='active' || filter==='today'&&status.kind==='today' || filter==='soon'&&status.kind==='soon' || filter==='review'&&['unknown','review','expired'].includes(status.kind) || filter==='history'&&item.status!=='active';
    return selected && (!search || `${item.name} ${matchFood(item.name,FOODS)?.en || ''}`.toLowerCase().includes(search.toLowerCase()));
  }).sort((a,b)=>(itemDate(a)||'9999').localeCompare(itemDate(b)||'9999'));
  return `${pageHead('我的食材',`一共 ${activeItems().length} 份在库，每个购买批次都单独记录。`,button(`${icon('plus')} 添加食材`,'new-item'))}<div class="toolbar"><label class="search">${icon('search')}<span class="visually-hidden">搜索食材，中英文均可</span><input id="inventory-search" type="search" placeholder="搜索食材，中英文均可" value="${esc(search)}"></label><div class="chips" aria-label="筛选食材">${[['active','全部在库'],['today','今天到期'],['soon','近期到期'],['review','需要确认'],['history','用完 / 丢弃']].map(([id,label])=>`<button type="button" class="chip ${filter===id?'active':''}" aria-pressed="${filter===id}" data-action="filter" data-filter="${id}">${label}</button>`).join('')}</div></div>
    ${rows.length?`<div class="inventory-grid">${rows.map(item=>{const food=matchFood(item.name,FOODS);return `<article class="inventory-card">${foodRow(item)}<div class="date-detail">${item.packageDate?`${DATE_TYPES[item.packageDateType]}：${esc(item.packageDate)}<br>`:''}${item.manualDate?`手动提醒：${esc(item.manualDate)}<br>`:''}${item.suggestedDate?`系统建议：${esc(item.suggestedDate)}<br>`:''}购买：${esc(item.purchasedOn || '未填写')} · ${CONDITIONS[item.condition]}${food?`<br>${esc(food.en)}`:''}</div><div class="card-actions">${button('修改记录','edit-item','soft small',`data-id="${esc(item.id)}"`)}${item.status==='active'?`${button('用完了','mark-used','ghost small',`data-id="${esc(item.id)}"`)}${button('丢弃','mark-discarded','ghost small',`data-id="${esc(item.id)}"`)}`:button('恢复在库','mark-active','ghost small',`data-id="${esc(item.id)}"`)}</div></article>`;}).join('')}</div>`:`<div class="panel">${emptyCard('🧺',search?'没有找到这份食材':'这里还没有记录',search?'试试其他名称，或录入一份新食材。':'添加食材后，可以在这里随时修改和更新。',button('添加食材','new-item','soft'))}</div>`}`;
}
function renderAdd() {
  return `${pageHead('把新鲜，记下来。','拍一张小票，或者从一份食材开始。')}<div class="add-grid"><section><div class="upload-card"><span class="upload-icon" aria-hidden="true">🧾</span><h2>一张小票，批量记好</h2><p>支持英国英文、中国中文与混合小票。<br>文字在这台设备里识别，图片不会上传。</p><label class="button" for="receipt-file">${icon('camera')} 拍照 / 选择小票</label><input id="receipt-file" type="file" accept="image/*"><p class="hint" style="margin-bottom:0">尽量拍清晰、拍平整，整张小票都在画面里。</p></div><div class="steps-mini"><span><b>1</b>拍小票</span><span><b>2</b>确认名称和日期</span><span><b>3</b>批量放进冰箱</span></div><div class="note">首次识别会加载本地识别程序和语言包。识别可能漏字或误认，确认清单后才会入库。<br>${button('已有小票文字？粘贴录入','paste-receipt','ghost small')}</div></section><section class="panel"><p class="eyebrow">ONE INGREDIENT AT A TIME</p><h2>也可以，一份一份记</h2><p class="hint" style="margin:13px 0 24px">没有小票也没关系。写个名字、加张照片，再记下包装上的日期就好。</p>${button(`${icon('plus')} 手动添加食材`,'new-item')}<div class="form-divider"></div><h3>日期应该怎么填？</h3><ul class="source-list"><li><b>有包装日期</b><br>记录 use-by、best-before 或保质期截止日。</li><li><b>散装蔬菜、生鲜</b><br>选好保存方式和状态，有适用参考时会给出建议。</li><li><b>已经开封或切开</b><br>参考包装开封说明，重新确认日期。</li></ul></section></div>`;
}
function renderRecipes() {
  const matches=ranked().filter(x=>recipeFilter==='mine'?state.recipes.some(r=>r.id===x.recipe.id):recipeFilter==='ready'?x.missing.length===0:true);
  return `${pageHead('今天的灵感，都在这里。','从现有食材出发，也记住自己的拿手菜。',button(`${icon('plus')} 记一道菜`,'new-recipe'))}<div class="toolbar"><div class="chips">${[['all','全部菜谱'],['ready','种类齐全'],['mine','我的私房菜']].map(([id,label])=>`<button type="button" class="chip ${recipeFilter===id?'active':''}" aria-pressed="${recipeFilter===id}" data-action="recipe-filter" data-filter="${id}">${label}</button>`).join('')}</div><span class="hint">${matches.length} 道 · 临期食材优先</span></div>${matches.length?`<div class="recipe-grid">${matches.map(recipeCard).join('')}</div>`:`<div class="panel">${emptyCard('📖',recipeFilter==='mine'?'记下你的第一道拿手菜':'还没有种类齐全的菜谱',recipeFilter==='mine'?'填入食材和做法，它也会参与每日推荐。':'看看全部菜谱的缺料提示，调料也需要记录在库。',button('记一道菜','new-recipe','soft'))}</div>`}<p class="note">“种类齐全”表示库存里有可用批次，不代表份量一定够。做饭前请确认食材状态与实际份量；烹饪后由你确认更新库存。</p>`;
}
function renderSettings() {
  return `${pageHead('让它，更合你的习惯。','数据留在当前设备，记得为自己的记录留一份备份。')}<div class="settings-grid"><section class="panel"><h2>临期范围</h2><form id="settings-form"><label class="field">未来多少天内需要优先处理？<select name="urgentDays">${Array.from({length:14},(_,i)=>`<option value="${i+1}" ${state.settings.urgentDays===i+1?'selected':''}>${i+1} 天</option>`).join('')}</select></label><p class="hint" style="margin-top:12px">用于首页分类和菜谱推荐。打开页面时更新，不发送后台通知。</p><button class="button" type="submit">保存设置</button></form></section><section class="panel"><h2>备份与恢复</h2><p class="hint">备份包含 ${state.items.length} 份食材、${state.recipes.length} 道个人菜谱、照片和设置。浏览器数据可能被清除，请定期保存到“文件”。</p><div style="display:flex;gap:10px;flex-wrap:wrap">${button('导出完整备份','export','soft')}${button('恢复备份','choose-backup','secondary')}</div><input type="file" id="backup-file" accept="application/json,.json" hidden><p class="hint" style="margin-top:12px">恢复前会显示内容数量，并明确确认替换。照片包含在备份文件里，请自行妥善保存。</p></section><section class="panel"><h2>离线使用</h2><p class="hint" id="offline-state">${offlineReady?'基础页面已可离线使用。':'正在检查离线缓存；首次打开需联网。'}</p><p class="hint" style="margin-top:10px">离线可查看食材、手动录入、编辑菜谱和匹配推荐。提前下载识别资源后，可离线识别中英文小票。</p>${button('下载离线识别资源','cache-ocr','soft')}<p class="hint" id="cache-status" style="margin-top:10px">需要下载较大的识别语言包，建议使用 Wi-Fi。</p></section><section class="panel"><h2>关于本地数据</h2><p class="hint">库存、照片和小票识别均在当前浏览器处理，不上传个人内容，不使用付费 AI。</p><p class="hint" style="margin-top:12px">不同手机、不同浏览器之间不会自动同步。清除网站数据或更换网址前，请先导出备份。无痕模式不适合长期保存。</p><p class="hint" style="margin-top:12px">可通过 Safari 分享菜单“添加到主屏幕”，更方便每天打开。</p></section><section class="panel wide"><h2>保存时间参考来源</h2><p class="hint">参考表覆盖 ${FOODS.length} 种常见食材。建议用于安排使用顺序，不能判断食材真实安全性。遵循包装日期及保存说明；存放条件改变后重新确认。</p><ul class="source-list">${SOURCES.map(source=>`<li><a href="${esc(source.url)}" target="_blank" rel="noopener noreferrer">${esc(source.title)} ↗</a><p class="hint">${esc(source.notes)}</p></li>`).join('')}</ul></section>${state.ocrHistory.length?`<section class="panel wide"><h2>小票识别试用记录</h2><p class="hint">只记录耗时与修改数，帮助你判断识别是否省事。</p><table class="history-table"><thead><tr><th>时间</th><th>语言</th><th>耗时</th><th>候选行</th><th>修改 / 移除</th></tr></thead><tbody>${state.ocrHistory.slice(-10).reverse().map(x=>`<tr><td>${esc(new Date(x.at).toLocaleDateString('zh-CN'))}</td><td>${esc(x.language)}</td><td>${Math.round(x.elapsedMs/1000)} 秒</td><td>${x.rows}</td><td>${x.corrections}</td></tr>`).join('')}</tbody></table></section>`:''}</div>`;
}
const options = (values,selected) => Object.entries(values).map(([value,label])=>`<option value="${value}" ${value===selected?'selected':''}>${esc(label)}</option>`).join('');
function defaultCondition(food) {
  if (food?.category==='肉类' || ['chicken','pork','beef','mince','shrimp','salmon'].includes(food?.id)) return 'raw';
  if (food?.category==='蔬菜' || food?.id==='apple') return 'whole';
  return 'unopened';
}
function newItem(name='') {
  const food=matchFood(name,FOODS);
  return {id:crypto.randomUUID(),name,quantity:'',storage:food?.storageRules[0]?.storage || 'fridge',condition:defaultCondition(food),purchasedOn:todayLocal(),packageDate:'',packageDateType:'none',manualDate:'',suggestedDate:'',suggestedSourceId:'',suggestedNote:'',status:'active',photo:'',dateNeedsReview:false,qualityCheckedOn:''};
}
function itemEditor(id) {
  const existing=state.items.find(x=>x.id===id), item=existing || newItem();
  photoDraft=item.photo;
  dialog(existing?'修改这份食材':'记一份新鲜',`<form id="item-form" data-id="${existing?esc(item.id):''}"><div class="form-grid"><label class="field full">食材名称<input name="name" required maxlength="100" list="food-names" placeholder="例如：西兰花 / broccoli" value="${esc(item.name)}"></label><datalist id="food-names">${FOODS.map(f=>`<option value="${esc(f.name)}">${esc(f.en)}</option>`).join('')}</datalist><label class="field">数量 / 份量<input name="quantity" maxlength="100" placeholder="例如：2 个 / 半袋" value="${esc(item.quantity)}"></label><label class="field">购买日期<input name="purchasedOn" type="date" value="${esc(item.purchasedOn)}"></label><label class="field">保存位置<select name="storage">${options(STORAGE,item.storage)}</select></label><label class="field">当前状态<select name="condition">${options(CONDITIONS,item.condition)}</select></label></div><fieldset class="form-section"><legend>日期，按包装和实际情况记录</legend><div class="form-grid"><label class="field">包装日期类型<select name="packageDateType">${options(DATE_TYPES,item.packageDateType)}</select></label><label class="field">包装上的截止日期<input type="date" name="packageDate" value="${esc(item.packageDate)}"></label><label class="field full">手动提醒日期（可选）<input name="manualDate" type="date" value="${esc(item.manualDate)}"><small class="hint">可提前提醒；不能延长原包装 use-by 或保质期截止日。</small></label></div><div id="date-suggestion"></div><label class="check-line" id="date-review-line" ${item.dateNeedsReview?'':'hidden'}><input type="checkbox" name="confirmDate"><span>我已根据新的保存 / 开封状态检查并确认日期。</span></label><label class="check-line"><input type="checkbox" name="qualityCheck" ${item.qualityCheckedOn===todayLocal()?'checked':''}><span>我今天已检查这份食材的品质及保存情况。<small class="hint" style="display:block">用于已过 best-before 或建议日期的食材，不适用于已过 use-by 或保质期截止日的食材。</small></span></label></fieldset><fieldset class="form-section"><legend>加张照片，找起来更方便</legend><div style="display:flex;align-items:center;gap:13px"><img class="preview-photo" id="item-photo-preview" ${item.photo?`src="${esc(item.photo)}"`:'hidden'} alt="食材照片预览"><label class="button secondary small" for="item-photo">${icon('camera')} 选择照片</label><input id="item-photo" name="photo" type="file" accept="image/*" hidden>${button('移除照片','remove-photo','ghost small')}</div><p class="hint" id="photo-status" style="margin-top:9px">照片会压缩并只保存在这台设备。</p></fieldset><p class="inline-message" id="item-error" role="alert"></p><div class="dialog-actions">${button('取消','close','secondary')}<button class="button" type="submit">${existing?'保存修改':'放进我的冰箱'}</button></div></form>`);
  updateSuggestion();
}
function readItemForm() {
  const form=$('#item-form'),values=Object.fromEntries(new FormData(form));
  return {...values,name:values.name.trim(),quantity:values.quantity.trim(),photo:photoDraft};
}
function updateSuggestion() {
  const form=$('#item-form'); if(!form) return;
  const values=readItemForm(),suggestion=suggestDate(values,FOODS),food=matchFood(values.name,FOODS);
  $('#date-suggestion').innerHTML=`<div class="suggestion">${suggestion?`<b>系统建议：${esc(suggestion.date)}</b><br>${esc(suggestion.note)}<br>${sourceLink(suggestion.sourceId)}`:`<b>暂时没有适用的自动建议</b><br>${esc(food?.note || '请根据包装说明或食材实际情况设置日期。')}`}<br><span class="hint">参考日期从购买日计算，仅作使用顺序提醒；包装和实际保存条件优先。</span></div>`;
  const old=state.items.find(x=>x.id===form.dataset.id);
  $('#date-review-line').hidden=!(old && (old.dateNeedsReview || old.storage!==values.storage || old.condition!==values.condition));
}
async function saveItem(form) {
  if(photoProcessing) throw new Error('照片仍在处理，请稍等片刻再保存。');
  const values=readItemForm(),old=state.items.find(x=>x.id===form.dataset.id),next=old?{...old}:newItem();
  if (!values.name) throw new Error('请填写食材名称。');
  if (values.packageDate && values.packageDateType==='none' || !values.packageDate && values.packageDateType!=='none') throw new Error('包装日期和日期类型需要一起填写。');
  const suggestion=suggestDate(values,FOODS);
  Object.assign(next,{name:values.name,quantity:values.quantity,purchasedOn:values.purchasedOn,storage:values.storage,condition:values.condition,packageDate:values.packageDate,packageDateType:values.packageDateType,manualDate:values.manualDate,photo:photoDraft,suggestedDate:suggestion?.date || '',suggestedSourceId:suggestion?.sourceId || '',suggestedNote:suggestion?.note || '',qualityCheckedOn:values.qualityCheck==='on'?todayLocal():''});
  const changed=old && (old.storage!==values.storage || old.condition!==values.condition || old.dateNeedsReview);
  next.dateNeedsReview=!!changed && values.confirmDate!=='on';
  const items=old?state.items.map(x=>x.id===old.id?next:x):[...state.items,next];
  await commit({...state,items},next.dateNeedsReview?'已保存，请确认变化后的日期':'食材已记好');
  modal.close();
}
async function imageData(file,max=1280,quality=.78) {
  if(file.size>25*1024*1024) throw new Error('图片较大，请选择 25 MB 以内的照片。');
  const url=URL.createObjectURL(file);
  try {
    const image=await new Promise((resolve,reject)=>{const image=new Image();image.onload=()=>resolve(image);image.onerror=()=>reject(new Error('无法读取这张图片，请尝试 JPG 或 PNG 照片。'));image.src=url;});
    const scale=Math.min(1,max/Math.max(image.naturalWidth,image.naturalHeight)),canvas=document.createElement('canvas');
    canvas.width=Math.max(1,Math.round(image.naturalWidth*scale));canvas.height=Math.max(1,Math.round(image.naturalHeight*scale));
    const context=canvas.getContext('2d');context.fillStyle='#fff';context.fillRect(0,0,canvas.width,canvas.height);context.drawImage(image,0,0,canvas.width,canvas.height);
    return canvas.toDataURL('image/jpeg',quality);
  } finally { URL.revokeObjectURL(url); }
}
function recipeEditor(id) {
  const recipe=allRecipes().find(x=>x.id===id);
  const existing=state.recipes.some(x=>x.id===id);
  dialog(existing?'修改我的菜谱':recipe?'保存为我的版本':'记一道拿手菜',`<form id="recipe-form" data-id="${existing?esc(id):''}"><div class="form-grid"><label class="field full">菜名<input name="name" required maxlength="100" value="${esc(recipe?.name || '')}" placeholder="例如：我的招牌焖饭"></label><label class="field">大约需要多久（分钟）<input type="number" name="minutes" min="0" max="1440" required value="${recipe?.minutes || 20}"></label><label class="field full">食材清单<textarea name="ingredients" required placeholder="鸡蛋 | 2 个&#10;番茄 | 1 个&#10;小葱 | 少许 | 可选">${esc(recipe?.ingredients.map(x=>`${x.name} | ${x.quantity || ''}${x.optional?' | 可选':''}`).join('\n') || '')}</textarea><small class="hint">每行一种，格式：名称 | 份量 | 可选。必需食材不用写“可选”，调料也请列出。</small></label><label class="field full">做法<textarea name="steps" required placeholder="每行写一个步骤">${esc(recipe?.steps.join('\n') || '')}</textarea></label></div><p class="inline-message" role="alert" id="recipe-error"></p><div class="dialog-actions">${existing?button('删除这道菜','delete-recipe','danger',`data-id="${esc(id)}"`):''}${button('取消','close','secondary')}<button class="button" type="submit">保存菜谱</button></div></form>`);
}
async function saveRecipe(form) {
  const values=Object.fromEntries(new FormData(form));
  const ingredients=values.ingredients.split('\n').map(x=>x.trim()).filter(Boolean).map(row=>{const [name,quantity='',optional='']=row.split('|').map(x=>x.trim());return {name,quantity,optional:optional==='可选'};});
  const steps=values.steps.split('\n').map(x=>x.trim()).filter(Boolean);
  if(!ingredients.length || ingredients.some(x=>!x.name) || !steps.length || !values.name.trim()) throw new Error('请填写菜名、食材和做法。');
  const recipe={id:form.dataset.id || crypto.randomUUID(),name:values.name.trim(),ingredients,steps,minutes:Number(values.minutes),emoji:'🍽️',tag:'我的私房菜'};
  await commit({...state,recipes:form.dataset.id?state.recipes.map(x=>x.id===recipe.id?recipe:x):[...state.recipes,recipe]},'菜谱已保存，也会参与今日推荐');
  modal.close();
}
function recipeDetail(id) {
  const match=ranked().find(x=>x.recipe.id===id); if(!match) return;
  const {recipe,available,missing,urgent}=match;
  dialog(recipe.name,`<p class="hint">${esc(recipe.emoji || '🍽️')} ${esc(recipe.tag || '我的私房菜')} · 约 ${recipe.minutes} 分钟</p>${urgent.length?`<div class="suggestion">优先用掉：${urgent.map(x=>esc(x.name)).join('、')}</div>`:''}<h3 style="margin-top:22px">需要这些食材</h3><ul class="ingredient-list">${recipe.ingredients.map(x=>{const found=available.includes(x);return `<li><span class="${!found&&!x.optional?'missing':''}">${found?'✓':'○'} ${esc(x.name)}${x.optional?' <small>可选</small>':''}</span><span>${esc(x.quantity || '适量')} · ${found?'库存有，确认份量':x.optional?'未记录':'还缺'}</span></li>`;}).join('')}</ul><p class="hint">${missing.length?`还缺 ${missing.map(x=>esc(x.name)).join('、')}。备齐后再开始做。`:'食材种类齐全，请检查实际份量与状态。'}</p><h3 style="margin-top:22px">这样做</h3><ol class="cooking-steps">${recipe.steps.map(step=>`<li>${esc(step)}</li>`).join('')}</ol><div class="dialog-actions">${button(state.recipes.some(x=>x.id===id)?'编辑菜谱':'存为我的版本','edit-recipe','secondary',`data-id="${esc(id)}"`)}${button('做过了，更新库存','cook','',`data-id="${esc(id)}"`)}</div>`);
}
function cookDialog(id) {
  const match=ranked().find(x=>x.recipe.id===id);if(!match) return;
  dialog('这一餐，用掉了哪些？',`<p class="hint">只更新你勾选或修改的批次，不自动扣减。未用完的可以改为实际剩余量。</p><form id="cook-form" data-id="${esc(id)}">${match.batches.length?match.batches.map(item=>`<div class="cook-row"><label class="check-line"><input type="checkbox" name="used" value="${esc(item.id)}"><span><b>${esc(item.name)}</b> · ${esc(item.quantity || '份量未填')}<br><small class="hint">${STORAGE[item.storage]} · ${esc(itemDate(item))} · 勾选表示这份已用完</small></span></label><label class="field">没用完，剩余多少？<input name="remaining-${esc(item.id)}" maxlength="100" value="${esc(item.quantity)}" placeholder="例如：半袋"></label></div>`).join(''):'<div class="note">当前没有可匹配的在库批次，库存不会改变。</div>'}<p class="hint" style="margin-top:15px">如果本次还使用了未匹配到的食材，请到“我的食材”单独更新。</p><div class="dialog-actions">${button('取消','close','secondary')}<button class="button" type="submit" ${match.batches.length?'':'disabled'}>确认更新库存</button></div></form>`);
}
async function saveCook(form) {
  const values=new FormData(form),used=new Set(values.getAll('used'));
  const allowed=new Set(ranked().find(x=>x.recipe.id===form.dataset.id)?.batches.map(x=>x.id) || []);
  const items=state.items.map(item=>allowed.has(item.id)?{...item,status:used.has(item.id)?'used':item.status,quantity:String(values.get(`remaining-${item.id}`) ?? item.quantity).trim()}:item);
  await commit({...state,items},'这一餐已记好，库存已更新');modal.close();
}
async function prepareReceipt(file) {
  const image=await imageData(file,2400,.9);
  receipt={image,text:'',rows:[],originalRows:[],elapsedMs:0,language:'英文',startedAt:0};
  receiptStart();
}
function receiptStart() {
  dialog('拍清楚，就记得住',`${receipt.image?`<img class="receipt-preview" src="${esc(receipt.image)}" alt="待识别小票">`:''}<label class="field">小票语言<select id="ocr-language"><option value="eng">英文</option><option value="chi_sim">简体中文</option><option value="eng+chi_sim">中英混合</option></select></label><p class="hint" style="margin-top:12px">识别在手机本地进行，不会上传图片。较长或模糊的小票可能需要更多时间。</p><div class="progress-track" hidden id="ocr-track"><div id="ocr-progress" style="width:0"></div></div><p class="hint" role="status" id="ocr-status"></p><p class="inline-message" role="alert" id="ocr-error"></p><div class="dialog-actions">${button('旋转图片 90°','rotate-receipt','secondary')}${button('粘贴文字','paste-receipt','secondary')}${button('开始识别','recognize')}</div>`);
}
function pasteReceipt() {
  receipt=receipt || {image:'',text:'',rows:[],originalRows:[],elapsedMs:0,language:'粘贴文字'};
  dialog('粘贴小票文字',`<form id="receipt-text-form"><label class="field">小票文字<textarea name="text" rows="10" required maxlength="30000" placeholder="TOMATOES 1.50&#10;FREE RANGE EGGS 2.30&#10;或直接粘贴中文小票内容">${esc(receipt.text)}</textarea></label><p class="hint" style="margin-top:12px">可使用 iPhone 照片的文字提取功能后粘贴。解析后仍可逐行修改。</p><div class="dialog-actions">${button('取消','close','secondary')}<button class="button" type="submit">生成待确认清单</button></div></form>`);
}
let ocrScript;
function loadOcrScript() {
  if(window.Tesseract) return Promise.resolve();
  if(!ocrScript) ocrScript=new Promise((resolve,reject)=>{const script=document.createElement('script');script.src='./vendor/tesseract.min.js';script.onload=resolve;script.onerror=()=>{ocrScript=null;script.remove();reject(new Error('识别程序加载失败，请联网重试，或选择粘贴文字 / 手动添加。'));};document.head.appendChild(script);});
  return ocrScript;
}
async function recognize() {
  const language=$('#ocr-language').value;receipt.language={eng:'英文',chi_sim:'中文','eng+chi_sim':'中英混合'}[language];
  const start=performance.now();let worker;
  $('#ocr-track').hidden=false;
  const status=$('#ocr-status'),bar=$('#ocr-progress');
  status.textContent='正在加载识别程序，请保持页面打开…';
  try {
    await loadOcrScript();
    const base=new URL('./vendor/',location.href);
    worker=await window.Tesseract.createWorker(language.split('+'),1,{
      workerPath:new URL('worker.min.js',base).href,
      corePath:new URL('core/',base).href,
      langPath:new URL('lang',base).href,
      workerBlobURL:false,
      logger:message=>{const percent=Math.round((message.progress || 0)*100);status.textContent=message.status==='recognizing text'?`正在识别文字 ${percent}%…`:'正在准备本地识别资源…';bar.style.width=`${Math.max(3,percent)}%`;},
    });
    await worker.setParameters({preserve_interword_spaces:'1'});
    const result=await worker.recognize(receipt.image);
    receipt.text=result.data.text;receipt.elapsedMs=Math.round(performance.now()-start);
    prepareRows();
  } catch(error) {
    $('#ocr-error').textContent=`${error.message || '识别失败'}。可重拍、粘贴文字或手动添加。`;
  } finally {if(worker) await worker.terminate();}
}
function prepareRows() {
  receipt.rows=parseReceipt(receipt.text,FOODS).map(row=>({...row,purchasedOn:todayLocal(),storage:'fridge',condition:defaultCondition(FOODS.find(x=>x.id===row.foodId)),manualDate:'',packageDate:'',packageDateType:'none',dateReviewed:false}));
  receipt.originalRows=structuredClone(receipt.rows);receiptReview();
}
function receiptReview() {
  dialog('确认一下，再放进冰箱',`<p class="hint">识别出 ${receipt.rows.length} 个候选项目。未知名称默认不勾选；请检查是否为食材。日期不会从小票金额或购买日期直接推断。</p><form id="receipt-review-form"><label class="field" style="margin-top:15px">本次购买日期<input id="receipt-purchase-date" type="date" value="${todayLocal()}" required></label><div id="receipt-rows">${receipt.rows.map((row,index)=>{
    const suggestion=suggestDate(row,FOODS);
    return `<div class="receipt-row" data-index="${index}"><div class="line"><input type="checkbox" data-field="selected" aria-label="录入${esc(row.name)}" ${row.selected?'checked':''}><label class="field" style="flex:1">食材名称<input data-field="name" maxlength="100" value="${esc(row.name)}"></label></div><p>原文：${esc(row.raw)}</p><div class="grid"><label class="field">数量<input data-field="quantity" maxlength="100" value="${esc(row.quantity)}" placeholder="实际份量"></label><label class="field">保存位置<select data-field="storage">${options(STORAGE,row.storage)}</select></label><label class="field">当前状态<select data-field="condition">${options(CONDITIONS,row.condition)}</select></label><label class="field">手动提醒日期<input type="date" data-field="manualDate"></label><label class="field">包装日期类型<select data-field="packageDateType">${options(DATE_TYPES,'none')}</select></label><label class="field">包装截止日期<input type="date" data-field="packageDate"></label></div><div class="receipt-date-hint" data-row-suggestion>${suggestion?`系统建议 ${esc(suggestion.date)} · 仅作提醒`:'无适用自动建议，请补充包装或手动日期。'}</div></div>`;}).join('')}</div>${!receipt.rows.length?'<p class="note">没有找到候选商品。可以编辑文字后重试，或手动添加。</p>':''}<p class="inline-message" role="alert" id="receipt-save-error"></p><div class="dialog-actions">${button('编辑识别文字','paste-receipt','secondary')}<button class="button" type="submit" ${receipt.rows.length?'':'disabled'}>确认勾选项目并入库</button></div></form>`);
}
function updateReceiptRow(element) {
  const container=element.closest('.receipt-row');if(!container) return;
  const row=receipt.rows[Number(container.dataset.index)],field=element.dataset.field;
  if(!field) return;
  row[field]=element.type==='checkbox'?element.checked:element.value;
  row.purchasedOn=$('#receipt-purchase-date').value;
  const suggestion=suggestDate(row,FOODS);
  $('[data-row-suggestion]',container).textContent=suggestion?`系统建议 ${suggestion.date} · 仅作提醒，包装优先`:'无适用自动建议，请补充包装或手动日期。';
}
async function saveReceipt() {
  const purchasedOn=$('#receipt-purchase-date').value;
  const selected=receipt.rows.filter(x=>x.selected);
  if(!selected.length) throw new Error('请至少勾选一个要录入的项目。');
  if(selected.some(x=>!x.name.trim())) throw new Error('勾选的项目都需要填写名称。');
  if(selected.some(x=>!!x.packageDate!==(x.packageDateType!=='none'))) throw new Error('请把包装日期和日期类型一起填写完整。');
  const items=selected.map(row=>{
    const next={...newItem(row.name.trim()),quantity:row.quantity.trim(),purchasedOn,storage:row.storage,condition:row.condition,manualDate:row.manualDate,packageDate:row.packageDate,packageDateType:row.packageDateType};
    const suggestion=suggestDate(next,FOODS);
    return {...next,suggestedDate:suggestion?.date || '',suggestedSourceId:suggestion?.sourceId || '',suggestedNote:suggestion?.note || ''};
  });
  const corrections=receipt.rows.reduce((sum,row,index)=>sum+(JSON.stringify([row.name,row.quantity,row.selected])!==JSON.stringify([receipt.originalRows[index]?.name,receipt.originalRows[index]?.quantity,receipt.originalRows[index]?.selected])?1:0),0);
  const log={at:new Date().toISOString(),language:receipt.language,elapsedMs:receipt.elapsedMs,rows:receipt.rows.length,corrections};
  await commit({...state,items:[...state.items,...items],ocrHistory:[...state.ocrHistory,log].slice(-100)},`已记好 ${items.length} 份食材`);
  receipt=null;modal.close();filter='active';navigate('inventory');
}
async function exportBackup() {
  const text=createBackup(state),blob=new Blob([text],{type:'application/json'}),name=`别放坏了-备份-${todayLocal()}.json`;
  const url=URL.createObjectURL(blob),link=document.createElement('a');link.href=url;link.download=name;document.body.appendChild(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),60000);
  toast('备份已生成，请在下载或“文件”中保存好。');
}
async function previewBackup(file) {
  restore=readBackup(await file.text());
  dialog('确认恢复这份备份？',`<p>备份包含 <b>${restore.items.length}</b> 份食材、<b>${restore.recipes.length}</b> 道个人菜谱，以及照片和设置。</p><div class="note">这会替换当前设备的 ${state.items.length} 份食材和 ${state.recipes.length} 道个人菜谱。建议先导出当前记录，确认后再恢复。</div><div class="dialog-actions">${button('先导出当前记录','export','secondary')}${button('取消','close','secondary')}${button('确认替换并恢复','restore','danger')}</div>`);
}
async function offlineResources() {
  if(!('caches' in window)) throw new Error('当前环境不支持离线缓存，请在 HTTPS 网站中打开。');
  const status=$('#cache-status');
  const response=await fetch('./ocr-assets.json');if(!response.ok) throw new Error('找不到识别资源清单，请先完成构建。');
  const files=await response.json(),cache=await caches.open('keep-fresh-ocr-v1');
  for(let index=0;index<files.length;index++) {
    status.textContent=`正在准备离线识别资源 ${index+1} / ${files.length}，请保持页面打开…`;
    const url=new URL(files[index],location.href).href;
    if(!await cache.match(url)) {const response=await fetch(url);if(!response.ok) throw new Error('有资源未下载成功，请联网重试。');await cache.put(url,response);}
  }
  status.textContent='中英文离线识别资源已下载。建议断网试识别一次确认。';toast('离线识别资源已准备');
}

document.addEventListener('click',async event=>{
  const target=event.target.closest('[data-action]');if(!target || busy) return;
  const action=target.dataset.action,id=target.dataset.id;
  try {
    if(action==='close') return closeDialog();
    if(action==='new-item' || action==='edit-item') return itemEditor(id);
    if(action==='go-add') return navigate('add');
    if(action==='inventory-filter'){filter=target.dataset.filter;return navigate('inventory');}
    if(action==='filter'){filter=target.dataset.filter;return render();}
    if(action==='recipe-filter'){recipeFilter=target.dataset.filter;return render();}
    if(action==='new-recipe' || action==='edit-recipe') return recipeEditor(id);
    if(action==='recipe') return recipeDetail(id);
    if(action==='cook') return cookDialog(id);
    if(action==='remove-photo'){photoDraft='';$('#item-photo-preview').hidden=true;$('#item-photo').value='';return;}
    if(action==='paste-receipt') return pasteReceipt();
    if(action==='export') return await exportBackup();
    if(action==='choose-backup') return $('#backup-file').click();
    if(action==='rotate-receipt') {
      const img=new Image();img.src=receipt.image;await img.decode();const canvas=document.createElement('canvas');canvas.width=img.naturalHeight;canvas.height=img.naturalWidth;const ctx=canvas.getContext('2d');ctx.translate(canvas.width,0);ctx.rotate(Math.PI/2);ctx.drawImage(img,0,0);receipt.image=canvas.toDataURL('image/jpeg',.9);return receiptStart();
    }
    busy=true;target.disabled=true;
    if(action.startsWith('mark-')) {
      const status=action.slice(5);
      if(status==='discarded'&&!confirm('确认将这份食材标记为丢弃？记录会保留在历史中。')) return;
      await commit({...state,items:state.items.map(x=>x.id===id?{...x,status}:x)},status==='used'?'已标记用完':status==='active'?'已恢复在库':'已标记丢弃');
    } else if(action==='delete-recipe') {
      if(confirm('删除这道个人菜谱？')) {await commit({...state,recipes:state.recipes.filter(x=>x.id!==id)},'菜谱已删除');modal.close();}
    } else if(action==='recognize') await recognize();
    else if(action==='restore') {await commit(restore,'备份已恢复');restore=null;modal.close();}
    else if(action==='cache-ocr') await offlineResources();
  } catch(error) {console.error(error);toast(error.message || '操作未完成，请重试。');}
  finally {busy=false;if(target.isConnected)target.disabled=false;}
});
document.addEventListener('submit',async event=>{
  event.preventDefault();if(busy) return;
  const form=event.target;busy=true;const submit=$('button[type=submit]',form);if(submit)submit.disabled=true;
  try {
    if(form.id==='item-form') await saveItem(form);
    else if(form.id==='recipe-form') await saveRecipe(form);
    else if(form.id==='cook-form') await saveCook(form);
    else if(form.id==='settings-form') await commit({...state,settings:{urgentDays:Number(new FormData(form).get('urgentDays'))}},'临期范围已更新');
    else if(form.id==='receipt-text-form') {receipt.text=new FormData(form).get('text');receipt.language='粘贴文字';receipt.elapsedMs=0;prepareRows();}
    else if(form.id==='receipt-review-form') await saveReceipt();
  } catch(error) {
    console.error(error);
    const errorId={'item-form':'#item-error','recipe-form':'#recipe-error','receipt-review-form':'#receipt-save-error'}[form.id];
    const message=error.name==='QuotaExceededError'?'设备存储不足，尚未保存。请先导出备份、腾出空间后重试。':error.message || '保存失败，原有记录未更改。';
    if(errorId && $(errorId)) $(errorId).textContent=message;else toast(message);
  } finally {busy=false;if(submit?.isConnected)submit.disabled=false;}
});
document.addEventListener('input',event=>{
  if(event.target.id==='inventory-search') {
    search=event.target.value;const position=event.target.selectionStart;render();const input=$('#inventory-search');input.focus();try{input.setSelectionRange(position,position);}catch{}
  }
  if(event.target.closest('#item-form') && event.target.type!=='file') updateSuggestion();
  if(event.target.closest('.receipt-row')) updateReceiptRow(event.target);
  if(event.target.id==='receipt-purchase-date') {
    for(const container of $$('.receipt-row')) updateReceiptRow($('[data-field=name]',container));
  }
});
document.addEventListener('change',async event=>{
  const input=event.target;
  if(input.closest('.receipt-row')) updateReceiptRow(input);
  if(input.name==='name' && input.closest('#item-form') && !$('#item-form').dataset.id) {
    const food=matchFood(input.value,FOODS);
    if(food && input.dataset.foodId!==food.id) {
      $('#item-form select[name=condition]').value=defaultCondition(food);
      $('#item-form select[name=storage]').value=food.storageRules[0]?.storage || 'fridge';
      input.dataset.foodId=food.id;
    }
  }
  if(input.closest('#item-form') && input.type!=='file') updateSuggestion();
  const file=input.files?.[0];if(!file) return;
  try {
    if(input.id==='receipt-file') {receipt=null;toast('正在准备小票图片…');await prepareReceipt(file);}
    else if(input.id==='item-photo') {
      const owner=$('#item-form');photoProcessing=true;$('#photo-status').textContent='正在压缩照片…';const image=await imageData(file);
      if($('#item-form')!==owner) return;
      photoDraft=image;$('#item-photo-preview').src=image;$('#item-photo-preview').hidden=false;$('#photo-status').textContent='照片已准备，只保存在当前设备。';
    } else if(input.id==='backup-file') await previewBackup(file);
  } catch(error) {toast(error.message || '文件读取失败，请重试。');}
  finally {photoProcessing=false;input.value='';}
});
modal.addEventListener('cancel',event=>{if(busy)event.preventDefault();});
window.addEventListener('hashchange',()=>{search='';render();window.scrollTo({top:0});});
document.addEventListener('visibilitychange',()=>{if(!document.hidden && !modal.open)render();});
window.addEventListener('online',()=>toast('已联网'));
window.addEventListener('offline',()=>toast('当前离线，已缓存内容仍可使用'));
async function start() {
  try {
    state=await loadState();render();
    if('serviceWorker' in navigator) {
      const registration=await navigator.serviceWorker.register('./sw.js');
      await navigator.serviceWorker.ready;offlineReady=true;
      if(page==='settings'&&$('#offline-state'))$('#offline-state').textContent='基础页面已可离线使用。';
      if(registration.waiting)toast('有新版本，关闭此网页后重新打开即可更新。');
    }
  } catch(error) {
    console.error(error);
    if($('#main .loading')) $('#main').innerHTML=`<div class="panel">${emptyCard('🧺','暂时无法打开本地记录','请退出无痕模式，检查是否允许网站保存数据，再重新打开。')}<p class="inline-message">${esc(error.message || '浏览器存储不可用')}</p><a class="button soft" href=".">重新打开</a></div>`;
    else toast('基础功能已打开，离线缓存暂未准备好。请保持联网。');
  }
}
start();
