// Storage estimates are planning reminders, not a determination that food is safe.
// Source ranges use the lower bound. Package instructions and dates take priority.
// Checked 2026-11-08. No rule applies after opening/cutting or changing storage.
export const SOURCES = [
  {
    id: 'foodkeeper',
    title: 'USDA FoodKeeper 食品保存参考',
    url: 'https://www.foodsafety.gov/keep-food-safe/foodkeeper-app',
    dataUrl: 'https://www.foodsafety.gov/sites/default/files/foodkeeper_data_url_en.json',
    notes: '美国 FoodKeeper 官方数据。建议日期按区间下限从购买日计算，仅用于安排优先使用；不能判断购买前的新鲜程度。冷藏需持续保持在 4°C 或以下，包装日期和保存说明优先。规则中的 sourceProductId 对应原数据条目编号。',
  },
  {
    id: 'usda-raw-meat',
    title: 'USDA：购买后生肉的冷藏时间',
    url: 'https://ask.fsis.usda.gov/article/How-long-can-I-keep-meat-in-the-refrigerator',
    notes: '生禽肉、绞肉及海鲜购买后冷藏 1–2 天内使用或冷冻。这里取下限作使用提醒，不覆盖包装日期。',
  },
  {
    id: 'fss-dates',
    title: 'Food Standards Scotland：use-by 与 best-before',
    url: 'https://www.foodstandards.gov.scot/consumer-advice/food-labels/use-by-and-best-before-dates',
    notes: 'use-by 涉及安全，过期后不应食用；best-before 涉及品质。日期仅在遵循包装保存条件时有效。英国带壳鸡蛋应优先记录包装日期，不将美国参考天数直接套用。',
  },
  {
    id: 'fsa-home-food',
    title: '英国 FSA：家庭食品保存常见问题',
    url: 'https://www.gov.uk/government/publications/home-food-fact-checker/home-food-fact-checker',
    notes: '熟米饭应快速冷却后冷藏，并在 24 小时内食用。鸡蛋优先参考包装日期并保持适当保存条件。',
  },
];

const chilled = (days, condition, sourceProductId, note) => ({
  storage: 'fridge', days, condition, sourceId: 'foodkeeper', sourceProductId, note,
});
const rawMeat = (days, note) => ({
  storage: 'fridge', days, condition: 'raw', sourceId: 'usda-raw-meat', note,
});

export const FOODS = [
  {
    id: 'tomato', name: '番茄', en: 'Tomato', emoji: '🍅', category: '蔬菜',
    aliases: ['西红柿', '番茄', 'tomato', 'tomatoes', 'vine tomatoes', 'salad tomatoes', 'toms', 'tom on vine', 'salad toms'],
    storageRules: [],
    note: 'FoodKeeper 的常温时间从成熟后起算，成熟程度无法由购买日确定。请检查食材或包装后设置日期，不自动估算。小番茄及切开的番茄条件另有不同。',
  },
  {
    id: 'egg', name: '鸡蛋', en: 'Eggs', emoji: '🥚', category: '蛋奶豆制品',
    aliases: ['鸡蛋', '鸡蛋盒', 'egg', 'eggs', 'free range eggs', 'free-range eggs', 'large eggs', 'medium eggs', '6 eggs', '12 eggs'],
    storageRules: [],
    note: '优先填写包装或蛋壳上的 best-before 日期。产蛋日期和购买日期不同，不按购买日增加固定天数；不要连壳冷冻。',
  },
  {
    id: 'broccoli', name: '西兰花', en: 'Broccoli', emoji: '🥦', category: '蔬菜',
    aliases: ['西兰花', '绿菜花', 'broccoli', 'calabrese'],
    storageRules: [chilled(3, 'whole', 276, '完整新鲜西兰花冷藏参考为 3–5 天，取 3 天提醒；包装有日期时优先使用包装日期。')],
    note: '仅适用于新鲜、未切、未烹调的西兰花；已切小朵或开袋产品请按标签设置。',
  },
  {
    id: 'carrot', name: '胡萝卜', en: 'Carrot', emoji: '🥕', category: '蔬菜',
    aliases: ['胡萝卜', '红萝卜', 'carrot', 'carrots', 'british carrots'],
    storageRules: [chilled(14, 'whole', 279, '完整胡萝卜冷藏参考为 2–3 周，取 14 天提醒。')],
    note: '仅适用于完整胡萝卜；切条、去皮和即食包装请按标签或另设日期。',
  },
  {
    id: 'spinach', name: '菠菜', en: 'Spinach', emoji: '🥬', category: '蔬菜',
    aliases: ['菠菜', 'spinach', 'baby spinach'],
    storageRules: [chilled(3, 'whole', 291, '新鲜菠菜冷藏参考为 3–7 天，取 3 天提醒。')],
    note: '适用于未切的新鲜菠菜；预洗即食袋装菠菜应优先记录 use-by 和开袋说明。',
  },
  {
    id: 'cabbage', name: '卷心菜', en: 'Cabbage', emoji: '🥬', category: '蔬菜',
    aliases: ['卷心菜', '包菜', '圆白菜', 'cabbage', 'white cabbage', 'red cabbage', 'savoy cabbage'],
    storageRules: [chilled(7, 'whole', 278, '完整卷心菜冷藏参考为 1–2 周，取 7 天提醒。')],
    note: '仅适用于完整卷心菜；切开的半颗、切丝和凉拌菜不套用此规则。',
  },
  {
    id: 'cucumber', name: '黄瓜', en: 'Cucumber', emoji: '🥒', category: '蔬菜',
    aliases: ['黄瓜', '青瓜', 'cucumber', 'cucumbers'],
    storageRules: [chilled(4, 'whole', 283, '完整黄瓜冷藏参考为 4–6 天，取 4 天提醒。')],
    note: '适用于新鲜完整黄瓜；切开后重新确认日期。',
  },
  {
    id: 'aubergine', name: '茄子', en: 'Aubergine', emoji: '🍆', category: '蔬菜',
    aliases: ['茄子', '长茄', 'aubergine', 'aubergines', 'eggplant'],
    storageRules: [chilled(4, 'whole', 284, '完整茄子冷藏参考为 4–7 天，取 4 天提醒。')],
    note: '适用于完整新鲜茄子，切开或烹调后不套用。',
  },
  {
    id: 'mushroom', name: '鲜蘑菇', en: 'Mushroom', emoji: '🍄', category: '蔬菜',
    aliases: ['蘑菇', '鲜蘑菇', '口蘑', '白蘑菇', 'mushroom', 'mushrooms', 'chestnut mushrooms', 'button mushrooms', 'closed cup mushrooms'],
    storageRules: [chilled(3, 'whole', 292, '新鲜蘑菇冷藏参考为 3–7 天，取 3 天提醒。')],
    note: '适用于新鲜完整蘑菇；干菇、切片和预制菇类请另设日期。',
  },
  {
    id: 'onion', name: '洋葱', en: 'Onion', emoji: '🧅', category: '蔬菜',
    aliases: ['洋葱', '红洋葱', '白洋葱', 'onion', 'onions', 'red onions', 'brown onions'],
    storageRules: [],
    note: 'FoodKeeper 以月提供完整洋葱参考，实际受完整程度和保存环境影响。请按当前状态设置提醒；切开后冷藏并重新确认日期。',
  },
  {
    id: 'spring-onion', name: '小葱', en: 'Spring onion', emoji: '🌱', category: '蔬菜',
    aliases: ['小葱', '香葱', '青葱', '葱', 'spring onion', 'spring onions', 'green onions', 'scallions'],
    storageRules: [chilled(7, 'whole', 295, '新鲜完整小葱冷藏参考为 1 周。')],
    note: '适用于完整新鲜小葱；切碎后不套用。',
  },
  {
    id: 'pepper', name: '甜椒', en: 'Bell pepper', emoji: '🫑', category: '蔬菜',
    aliases: ['甜椒', '彩椒', '青椒', '红椒', '黄椒', 'bell pepper', 'peppers', 'mixed peppers', 'sweet peppers', 'red pepper', 'green pepper'],
    storageRules: [chilled(4, 'whole', 296, '完整甜椒冷藏参考为 4–14 天，取 4 天提醒。')],
    note: '适用于新鲜完整甜椒；切开、加工及辣椒产品请另设日期。',
  },
  {
    id: 'potato', name: '土豆', en: 'Potato', emoji: '🥔', category: '蔬菜',
    aliases: ['土豆', '马铃薯', 'potato', 'potatoes', 'white potatoes', 'baking potatoes', 'maris piper'],
    storageRules: [],
    note: 'FoodKeeper 推荐完整土豆常温保存，参考按月给出。这里不自动把月份换算成保质期；请根据状态和包装设置。切开的土豆、土豆泥和发绿发芽土豆另行处理。',
  },
  {
    id: 'garlic', name: '大蒜', en: 'Garlic', emoji: '🧄', category: '蔬菜',
    aliases: ['大蒜', '蒜', '蒜头', '蒜瓣', 'garlic', 'garlic bulb', 'garlic bulbs'],
    storageRules: [],
    note: '整头蒜和分离蒜瓣的保存条件不同，蒜蓉、油浸蒜也不同。不统一估算，请确认状态后设置日期。',
  },
  {
    id: 'ginger', name: '生姜', en: 'Ginger', emoji: '🫚', category: '蔬菜',
    aliases: ['生姜', '姜', '老姜', 'ginger', 'root ginger', 'ginger root'],
    storageRules: [chilled(14, 'whole', 286, '完整姜根冷藏参考为 2–3 周，取 14 天提醒。')],
    note: '适用于完整姜根；去皮、切片、磨蓉后请另设日期。',
  },
  {
    id: 'chicken', name: '鸡肉', en: 'Chicken', emoji: '🍗', category: '肉类海鲜',
    aliases: ['鸡肉', '鸡胸肉', '鸡腿', '鸡胸', '鸡腿肉', 'chicken', 'chicken breast', 'chicken breasts', 'chicken thigh', 'chicken thighs', 'chkn breast', 'chk breast', 'ckn breast', 'chicken fillets'],
    storageRules: [rawMeat(1, '生鸡肉购买后冷藏 1–2 天内使用或冷冻，取 1 天提醒；包装 use-by 较早时以包装为准。')],
    note: '仅适用于生鸡肉且持续正确冷藏。熟鸡肉、腌制或即食鸡肉按标签另设日期。',
  },
  {
    id: 'pork', name: '猪肉', en: 'Pork', emoji: '🥩', category: '肉类海鲜',
    aliases: ['猪肉', '猪里脊', '里脊肉', '排骨', 'pork', 'pork loin', 'pork chops', 'pork steaks', 'pork tenderloin'],
    storageRules: [chilled(3, 'raw', 69, '生猪里脊等完整切块冷藏参考为 3–5 天，取 3 天提醒；绞肉需使用绞肉条目。')],
    note: '适用于完整生猪肉切块、排骨等；绞肉、内脏、熟肉不套用。',
  },
  {
    id: 'beef', name: '牛肉', en: 'Beef', emoji: '🥩', category: '肉类海鲜',
    aliases: ['牛肉', '牛排', '牛腩', 'beef', 'beef steak', 'beef steaks', 'beef strips', 'diced beef', 'beef rump'],
    storageRules: [chilled(3, 'raw', 40, '完整生牛肉切块、牛排等冷藏参考为 3–5 天，取 3 天提醒；绞肉需使用绞肉条目。')],
    note: '适用于完整生牛肉切块；绞肉、内脏、熟肉不套用。',
  },
  {
    id: 'mince', name: '绞肉', en: 'Mince', emoji: '🥩', category: '肉类海鲜',
    aliases: ['绞肉', '肉末', '肉馅', '猪肉馅', '牛肉馅', '猪肉末', '牛肉末', 'mince', 'beef mince', 'pork mince', 'minced beef', 'minced pork', 'ground beef', 'ground pork'],
    storageRules: [rawMeat(1, '生绞肉购买后冷藏 1–2 天内使用或冷冻，取 1 天提醒。')],
    note: '仅适用于生绞肉。绞肉比完整肉块保存时间短，不能套用完整牛肉或猪肉规则。',
  },
  {
    id: 'shrimp', name: '鲜虾', en: 'Raw prawns', emoji: '🦐', category: '肉类海鲜',
    aliases: ['鲜虾', '虾', '虾仁', '生虾', 'prawns', 'raw prawns', 'king prawns', 'raw king prawns', 'shrimp', 'shrimps'],
    storageRules: [rawMeat(1, '生海鲜购买后冷藏 1–2 天内使用或冷冻，取 1 天提醒。')],
    note: '仅适用于生虾。熟虾、冷冻虾和已解冻产品请根据包装及状态另设日期。',
  },
  {
    id: 'salmon', name: '三文鱼', en: 'Salmon', emoji: '🐟', category: '肉类海鲜',
    aliases: ['三文鱼', '鲑鱼', 'salmon', 'salmon fillet', 'salmon fillets', 'atlantic salmon'],
    storageRules: [rawMeat(1, '生鱼购买后冷藏 1–2 天内使用或冷冻，取 1 天提醒。')],
    note: '仅适用于生鲜三文鱼。烟熏、熟制、冷冻或解冻三文鱼不套用。',
  },
  {
    id: 'tofu', name: '豆腐', en: 'Tofu', emoji: '◻️', category: '蛋奶豆制品',
    aliases: ['豆腐', '嫩豆腐', '老豆腐', '北豆腐', '南豆腐', 'tofu', 'firm tofu', 'silken tofu', 'bean curd'],
    storageRules: [chilled(7, 'unopened', 168, 'FoodKeeper 豆腐冷藏参考为 1 周，仅作未开封冷藏产品的提醒，包装日期优先。')],
    note: '品种和工艺差异较大，包装 use-by 及开封说明优先；散装豆腐、开封豆腐和常温无菌豆腐另设日期。',
  },
  {
    id: 'milk', name: '牛奶', en: 'Milk', emoji: '🥛', category: '蛋奶豆制品',
    aliases: ['牛奶', '鲜奶', '全脂牛奶', '脱脂牛奶', 'milk', 'whole milk', 'semi skimmed milk', 'semi-skimmed milk', 'skimmed milk', 'whole mlk'],
    storageRules: [],
    note: 'FoodKeeper 普通牛奶直接要求参考包装 use-by。巴氏奶、超高温奶及常温奶不同，请填写包装日期和开封说明。',
  },
  {
    id: 'yogurt', name: '酸奶', en: 'Yogurt', emoji: '🥣', category: '蛋奶豆制品',
    aliases: ['酸奶', '酸乳', 'yogurt', 'yoghurt', 'greek yogurt', 'greek yoghurt', 'natural yogurt', 'natural yoghurt'],
    storageRules: [chilled(7, 'unopened', 33, 'FoodKeeper 酸奶冷藏参考为 1–2 周，取 7 天作未开封产品的提醒，包装日期优先。')],
    note: '适用于未开封、持续冷藏的酸奶；开封后请按包装说明重新确认日期。',
  },
  {
    id: 'apple', name: '苹果', en: 'Apple', emoji: '🍎', category: '水果',
    aliases: ['苹果', 'apple', 'apples', 'gala apples', 'pink lady apples', 'royal gala'],
    storageRules: [
      chilled(28, 'whole', 248, '完整苹果冷藏参考为 4–6 周，取 28 天提醒。'),
      { storage: 'pantry', days: 21, condition: 'whole', sourceId: 'foodkeeper', sourceProductId: 248, note: '完整苹果常温参考为 3 周；实际成熟程度仍需检查。' },
    ],
    note: '适用于完整苹果；切开、损伤或加工后请另设日期。',
  },
  {
    id: 'rice', name: '大米', en: 'Dry rice', emoji: '🍚', category: '主食',
    aliases: ['大米', '生米', '白米', '香米', 'rice', 'white rice', 'jasmine rice', 'basmati rice', 'long grain rice'],
    storageRules: [],
    note: '指未煮熟干米，请按包装 best-before 和防潮防虫要求设置日期。熟米饭不能套用干米日期，英国建议尽快冷却冷藏并在 24 小时内食用。',
  },
  {
    id: 'noodles', name: '面条', en: 'Noodles', emoji: '🍜', category: '主食',
    aliases: ['面条', '挂面', '面', 'noodles', 'egg noodles', 'dry noodles', 'dried noodles', 'wheat noodles'],
    storageRules: [],
    note: '鲜面、干面和熟面保存条件差异很大，按包装日期和保存说明设置，不统一估算。',
  },
  {
    id: 'soy-sauce', name: '酱油', en: 'Soy sauce', emoji: '🫙', category: '调料',
    aliases: ['酱油', '生抽', '老抽', 'soy sauce', 'light soy sauce', 'dark soy sauce', 'soya sauce'],
    storageRules: [],
    note: '不同配方及开封后要求不同，请记录包装日期和开封说明；不按购买日统一推算。',
  },
  {
    id: 'oil', name: '食用油', en: 'Cooking oil', emoji: '🫒', category: '调料',
    aliases: ['油', '食用油', '植物油', '橄榄油', '菜籽油', '葵花籽油', 'cooking oil', 'vegetable oil', 'olive oil', 'sunflower oil', 'rapeseed oil'],
    storageRules: [],
    note: '油种、开封状态和光照温度影响保存时间，请按包装 best-before 和保存条件设置。',
  },
  {
    id: 'salt', name: '盐', en: 'Salt', emoji: '🧂', category: '调料',
    aliases: ['盐', '食盐', '海盐', '碘盐', 'salt', 'table salt', 'sea salt', 'iodised salt'],
    storageRules: [],
    note: '普通盐与调味盐不同，不自动生成到期日。可按包装设置提醒，保持干燥。',
  },
];
