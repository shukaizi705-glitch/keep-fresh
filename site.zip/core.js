export const STORAGE = { fridge: '冷藏', freezer: '冷冻', pantry: '常温' };
export const CONDITIONS = { whole: '完整未切', raw: '生鲜未烹调', unopened: '未开封', opened: '已开封 / 切开', other: '其他 / 不确定' };
export const DATE_TYPES = { none: '没有包装日期', 'use-by': 'Use-by · 安全期限', 'best-before': 'Best-before · 品质期限', expiry: '保质期截止日' };
export const todayLocal = () => {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
};
const utc = date => Date.parse(`${date}T00:00:00Z`);
export function validDate(date) {
  return typeof date === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(date) && Number.isFinite(utc(date)) && new Date(utc(date)).toISOString().slice(0,10) === date;
}
export function addDays(date, days) {
  if (!validDate(date)) return '';
  return new Date(utc(date) + days * 86400000).toISOString().slice(0,10);
}
export function daysUntil(date, today = todayLocal()) { return Math.round((utc(date)-utc(today))/86400000); }
export function itemDate(item) {
  let date = item.manualDate || item.packageDate || item.suggestedDate || '';
  if (['use-by','expiry'].includes(item.packageDateType) && item.packageDate && (!date || date > item.packageDate)) date = item.packageDate;
  return date;
}
export function itemStatus(item, today = todayLocal(), urgentDays = 3) {
  const date = itemDate(item);
  const days = date ? daysUntil(date, today) : null;
  if (item.status !== 'active') return {kind: item.status, usable:false, days, label: item.status === 'used' ? '已用完' : '已丢弃'};
  if (item.packageDate && ['use-by','expiry'].includes(item.packageDateType) && item.packageDate < today) return {kind:'expired',usable:false,days,label:'已过安全期限'};
  if (item.dateNeedsReview) return {kind:'review',usable:false,days,label:'保存状态已变 · 请确认日期'};
  if (!date) return {kind:'unknown',usable:false,days:null,label:'日期待确认'};
  const pastQuality = item.packageDateType === 'best-before' && item.packageDate && item.packageDate < today;
  const pastSuggestion = !item.packageDate && item.suggestedDate && item.suggestedDate < today;
  if ((pastQuality || pastSuggestion || days < 0) && item.qualityCheckedOn !== today) return {kind:'review',usable:false,days,label:pastQuality ? '已过品质期限 · 请检查' : '已过建议日期 · 请检查'};
  if (days < 0) return {kind:'today',usable:true,days,label:'今天已检查 · 尽快使用'};
  if (days === 0) return {kind:'today',usable:true,days,label:'今天到期'};
  if (days <= urgentDays) return {kind:'soon',usable:true,days,label:`还有 ${days} 天`};
  return {kind:'fresh',usable:true,days,label:`还有 ${days} 天`};
}
const normal = text => String(text || '').normalize('NFKC').toLowerCase().replace(/[\s_\-]+/g,' ').trim();
const escapeRegex = text => text.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
export function matchFood(text, foods) {
  const value = normal(text);
  const matches = [];
  for (const food of foods) {
    for (const alias of [food.name, food.en, ...(food.aliases || [])].filter(Boolean)) {
      const word = normal(alias);
      const found = /[\u3400-\u9fff]/.test(word) ? (word.length===1 ? value===word : value.includes(word)) : new RegExp(`(?:^|[^a-z])${escapeRegex(word)}(?:$|[^a-z])`,'i').test(value);
      if (found) matches.push({food, length:word.length});
    }
  }
  return matches.sort((a,b)=>b.length-a.length)[0]?.food || null;
}
export function suggestDate(item, foods) {
  const food = matchFood(item.name, foods);
  const rule = food?.storageRules.find(rule => rule.storage === item.storage && rule.condition === item.condition);
  if (!rule || !validDate(item.purchasedOn)) return null;
  return {date:addDays(item.purchasedOn, rule.days), sourceId:rule.sourceId, note:rule.note || food.note, days:rule.days};
}
const key = (name, foods) => matchFood(name, foods)?.id || normal(name);
export function rankRecipes(recipes, items, foods, today = todayLocal(), urgentDays = 3) {
  const usable = items.filter(item=>itemStatus(item,today,urgentDays).usable);
  const inventory = new Map();
  for (const item of usable) {
    const id = key(item.name,foods);
    if (!inventory.has(id)) inventory.set(id,[]);
    inventory.get(id).push(item);
  }
  return recipes.map(recipe=>{
    const available = [], missing = [], urgent = [], batches = [];
    for (const ingredient of recipe.ingredients) {
      const matching = [...(inventory.get(key(ingredient.name,foods)) || [])].sort((a,b)=>(itemDate(a)||'9999').localeCompare(itemDate(b)||'9999'));
      if (matching.length) {
        available.push(ingredient);
        batches.push(...matching);
        if (matching.some(item=>itemStatus(item,today,urgentDays).days <= urgentDays)) urgent.push({...ingredient, name:matchFood(ingredient.name,foods)?.name || ingredient.name});
      } else if (!ingredient.optional) missing.push(ingredient);
    }
    return {recipe, available, missing, urgent, batches:[...new Map(batches.map(item=>[item.id,item])).values()]};
  }).sort((a,b)=>b.urgent.length-a.urgent.length || a.missing.length-b.missing.length || b.available.length-a.available.length || a.recipe.name.localeCompare(b.recipe.name,'zh-CN'));
}
export function parseReceipt(text, foods) {
  // ponytail: receipt layouts vary; all rows remain editable and require confirmation.
  const skip = /^(?:total|subtotal|sub total|vat|visa|mastercard|cash|change|balance|discount|clubcard|tesco|sainsbury'?s|aldi|lidl|asda|waitrose|morrisons|receipt|thank|tel|www\.|http|合计|总计|实付|应付|找零|优惠|收银|交易|门店|欢迎|电话|地址|数量|商品名称|支付|现金|银行卡|会员)/i;
  return String(text).split(/\r?\n/).map(line=>line.trim()).filter(Boolean).flatMap(raw=>{
    if (skip.test(raw) || !/[a-z\u3400-\u9fff]/i.test(raw) || /^\d{1,4}[\/-]\d{1,2}[\/-]\d{1,4}/.test(raw)) return [];
    const hasPrice = /[£¥￥]?\d+[.,]\d{2}\s*[A-Z*]?$/i.test(raw);
    let name = raw.replace(/\s*[£¥￥]?\d+[.,]\d{2}\s*[A-Z*]?$/i,'').trim();
    const quantity = name.match(/^(\d+)\s*[x×]\s*/i);
    name = name.replace(/^\d+\s*[x×]\s*/i,'').trim();
    const food = matchFood(name, foods);
    if (!food && !hasPrice || !name) return [];
    return [{name:food?.name || name, quantity:quantity?.[1] || '', foodId:food?.id || '', raw, selected:!!food}];
  }).slice(0,100);
}
export function createBackup(data) {
  return JSON.stringify({format:'keep-fresh',version:1,exportedAt:new Date().toISOString(),data},null,2);
}
export function emptyState() { return {items:[],recipes:[],settings:{urgentDays:3},ocrHistory:[]}; }
export function validateState(data) {
  const fail = () => { throw new Error('备份格式不正确或包含不支持的数据，尚未更改现有记录。'); };
  const str = (value, max=1000) => typeof value === 'string' && value.length <= max;
  const date = value => value === '' || value === undefined || validDate(value);
  const unique = rows => new Set(rows.map(x=>x.id)).size === rows.length;
  if (!data || !Array.isArray(data.items) || !Array.isArray(data.recipes) || data.items.length>10000 || data.recipes.length>1000 || !unique(data.items) || !unique(data.recipes)) fail();
  if (!Number.isInteger(data.settings?.urgentDays) || data.settings.urgentDays < 1 || data.settings.urgentDays > 14) fail();
  for (const item of data.items) {
    if (!str(item.id,100) || !item.id || !str(item.name,100) || !item.name.trim() || !str(item.quantity,100) || !Object.hasOwn(STORAGE,item.storage) || !Object.hasOwn(CONDITIONS,item.condition) || !Object.hasOwn(DATE_TYPES,item.packageDateType) || !['active','used','discarded'].includes(item.status)) fail();
    if (!['purchasedOn','packageDate','manualDate','suggestedDate','qualityCheckedOn'].every(field=>date(item[field])) || typeof item.dateNeedsReview !== 'boolean') fail();
    if (item.packageDate && item.packageDateType === 'none') fail();
    if (!str(item.photo,3000000) || item.photo && !/^data:image\/(?:jpeg|png|webp);base64,[A-Za-z0-9+/=]+$/.test(item.photo)) fail();
  }
  for (const recipe of data.recipes) {
    if (!str(recipe.id,100) || !recipe.id || !str(recipe.name,100) || !recipe.name.trim() || !Array.isArray(recipe.ingredients) || !recipe.ingredients.length || recipe.ingredients.length > 100 || !Array.isArray(recipe.steps) || recipe.steps.length>100) fail();
    if (!recipe.ingredients.every(x=>x && str(x.name,100) && x.name.trim() && str(x.quantity || '',100) && typeof x.optional==='boolean') || !recipe.steps.every(x=>str(x,2000)) || !Number.isFinite(recipe.minutes) || recipe.minutes<0 || recipe.minutes>1440) fail();
  }
  if (!Array.isArray(data.ocrHistory || []) || (data.ocrHistory || []).length>1000 || !(data.ocrHistory || []).every(x=>x && str(x.at,100) && str(x.language,30) && ['elapsedMs','rows','corrections'].every(field=>Number.isFinite(x[field])&&x[field]>=0))) fail();
  return {items:data.items,recipes:data.recipes,settings:{urgentDays:data.settings.urgentDays},ocrHistory:data.ocrHistory || []};
}
export function readBackup(text) {
  let backup;
  try { backup = JSON.parse(text); } catch { throw new Error('无法读取 JSON 备份，尚未更改现有记录。'); }
  if (backup?.format !== 'keep-fresh' || backup.version !== 1) throw new Error('这不是支持的「别放坏了」备份文件。');
  return validateState(backup.data);
}
